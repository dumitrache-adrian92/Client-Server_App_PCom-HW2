Tema 2 PCom - Aplicatie client-server TCP si UDP

Bibliografie:
- laboratorul 6 pentru a invata cum sa folosesc UDP
- laboratorul 7 pentru a invata cum sa folosesc TCP si poll pentru multiplexare
- man page-uri pentru functiile de biblioteca folosite

Protocol:
Clientii UDP pot trimite mesaje in formatul oferit in cerinta, acestea vor
fi mai departe interpretate de catre server utilizand structura udp_message, la
care poate fi castat direct mesajul.
Clientii TCP se conecteaza la server si trimit un prim mesaj ce contine ID-ul
lor. Dupa acest prim pas, clientii pot trimite mesaje utilizand structura
tcp_to_server_message, aceasta structura descrie mesaje in formatul din cerinta
(subscribe/unsubscribe <topic> <<SF> sau nimic pentru unsubscribe>).
Serverul va primi mesaje de la clientii UDP si TCP (doar in formaturile
descrise mai sus).
In cazul clientilor TCP, serverul isi va actualiza
structurile interne in functie de comenzile de subscribe/unsubscribe primite.
In cazul clientilor UDP, serverul va converti mesajul primit intr-un format
descris de structura tcp_to_client_message si il va trimite tuturor clientilor
abonati la topicul respectiv. Este folosit un mecanism de eficientizare:
inainte sa trimitem mesajele tcp_to_client_message, trimitem lungimea
continutului si apoi trimitem mesajul cu exact cati octeti avem nevoie sa
trimitem. Acest lucru este important deoarece lungimea continutului este extrem
de variabiala (2-1500 de octeti) si e inutil sa trimitem mereu 1500 de octeti
cand relevanti erau defapt 2. Ulterior, este rolul clientului TCP sa
interpreteze structura tcp_to_client_message si sa afiseze mesajul
corespunzator. Clientii TCP vor citi mai intai lungimea cotinutului si apoi
toata structura cand au ceva de citit de la server.

Deci avem trei structuri ce reprezinta protocolul nostru de nivel aplicatie:
- udp_message: structura ce descrie mesajele primite de la clientii UDP
- tcp_to_server_message: structura ce descrie mesajele primite de la clientii
de catre server
- tcp_to_client_message: structura ce descrie mesajele trimise de server catre
clienti, este practic udp_message la care adaugam IP-ul si portul clientului
UDP ce a trimis mesajul

Este rolul clientilor si serverului sa interpreteze aceste mesaje, fie pentru
a le afisa (pentru clientii TCP), fie a trimite mai departe informatiile
(pentru server) sau pentru a actualiza statusul aplicatiei (pentru server).

Server:
Acesta, odata pornit, tine deschisi 2 socketi, unul pentru a primi mesaje de la
clientii UDP si altul pentru a primi cereri de conectare de la clientii TCP.
Se creaza si alti socketi TCP cand clientii se conecteaza la server, acestia
vor fi folositi in continuare pentru comunicarea intre clienti si server.

Aceste conexiuni, alaturi de stdin, sunt multiplexate utilizand API-ul de poll
scopul fiind sa putem primi mesaje de oriunde, in orice ordine si oricand, cat
si sa putem primi input de la utilizator in orice moment.

Se folosesc cateva structuri de date pentru a retine informatii legate de
clienti si de mesaje, cum ar fi:
- vectorul online: retine ID-urile clientilor TCP ce sunt conectati in acest
moment
- fd_to_id: este un dictionar ce imperecheaza descriptorii de fisier cu
ID-urile corespunzatoare
- topic: un dictionar ce imperecheaza topicurile cu un vector ce contine
ID-urile abonatilor lor
- stored_messages: un dictionar ce imperecheaza ID-urile clientilor cu mesajele
pe care acestia le-au primit cat timp erau offline

Este folosit si un fisier de log pentru a afisa erori necerute de cerinta
temei, precum input de la tastatura invalid.

Modul de functionare este urmatorul:
- asteptam date de la descriptorii de fisier adaugati in vectorul folosit de
poll
- daca avem date de citit de la stdin, atunci verificam ca aceste date sa fie
"exit" si sa incheiem functionarea serverului, altfel scriem in fisierul de log
ca s-a dat o comanda invalida (singurul input valid e exit)
- daca primim date pe socketul TCP dedicat noilor conexiuni, atunci acceptam
conexiunea si asteptam ca acesta sa ne trimita in plain text ID-ul sau, daca
ID-ul nu a fost deja folosit, atunci adaugam clientul in lista de conexiuni
folosita de poll si actualizam corespunzator structurile de date interne ale
serverului, altfel afisam mesajul corespunzator la stdout si inchidem
conexiunea
- daca primim date pe un socket TCP dedicat unui client deja conectat, atunci
interpretam mesajul si actualizam structurile de date interne ale serverului
(practic il adaugam sau il scoatem pe clientul respectiv dintr-o lista de
abonati al unui topic)
- daca primim date pe socketul UDP, atunci interpretam mesajul si il convertim
intr-un mesaj de tipul tcp_to_client_message si il trimitem tuturor clientilor
ce sunt abonati la topicul mesajului

Client TCP:
Acesta primeste ca argumente in linia de comanda ID-ul cu care vrea
utilizatorul sa se conecteze, IP-ul serverului si portul serverului.

Clientul va verifica daca argumentele sunt valide si va deschide un socket TCP
pentru a comunica cu serverul. Dupa ce se conecteaza, va trimite ID-ul sau in
plain text. Daca serverul inchide conexiunea, inseamna ca ID-ul este deja
folosit, iar clientul se va opri.

Conexiunea cu serverul este multiplexata cu stdin utilizand poll, astfel incat
sa putem trimite, primi si citi input de la stdin oricand si in orice ordine.

Este folosit si un fisier de log pentru a afisa erori necerute de cerinta
temei, precum input de la tastatura invalid.

Modul de functionare este urmatorul:
- asteptam date de la descriptorii de fisier adaugati in vectorul folosit de
poll
- daca avem de citit de la stdin inseamna ca utilizatorul a dat o comanda,
aceasta poate sa fie exit, caz in care inchidem clientul si conexiunea catre
server, sau o comanda de tip subscribe/unsubscribe valida, caz in care o
convertim la o structura de tip tcp_to_server_message si o trimitem catre
server; pentru comenzi invalide ignoram comanda si scriem in log ca s-a dat un
input invalid
- daca avem de citit de la socketul TCP catre server, inseamna ca am primit un
mesaj de tipul tcp_to_client_message, moment in care citim de la server
lungimea continutului si citim apoi exact cati octeti este structura trimisa de
catre server (lucru determinat usor prin faptul ca noi cunoastem lungimea
continutului, iar restul structurii nu variaza ca lungime), interpretam
structura si afisam un mesaj la stdout in formatul cerut.

In caz de eroare legata de apeluri de sistem, toate conexiunile vor fi inchise,
memoria va fi eliberata si programul se va opri cu cod de eroare.